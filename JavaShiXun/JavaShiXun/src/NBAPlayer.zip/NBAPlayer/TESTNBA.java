/**
 * 
 */
package NBAPlayer;

import NBAPlayer.VIEWNba;

/**
*  @Description     NBA1.0
*  @author          孙豪
*  @version         1.0
*  @Date            2020年7月2日下午9:28:08
*/
@SuppressWarnings("unused")
public class TESTNBA 
{
	public static void main(String[] args) 
	{
		VIEWNba view = new VIEWNba();
		view.menu1();//系统入口
	}
}
