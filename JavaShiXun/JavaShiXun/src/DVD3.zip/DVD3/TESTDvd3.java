/**
 * 
 */
package DVD3;


import DVD3.JDBCUtil;
/**
*  @Description     DVD3.0
*  @author          孙豪
*  @version         3.0.1
*  @Date            2020年7月2日下午12:44:19
*/
@SuppressWarnings("unused")
public class TESTDvd3 
{
	public static void main(String[] args) 
	{
		VIEWDvd3 view = new VIEWDvd3();
		view.menu1();
	}
}
